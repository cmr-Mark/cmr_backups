import * as vscode from 'vscode';
import { Snapshot } from '../models/snapshot';
import { FileUtils } from '../utils/fileUtils';
import * as fs from 'fs';
import * as path from 'path';

export class SnapshotStorage {
    constructor(private context: vscode.ExtensionContext) {}

    async saveSnapshot(snapshot: Snapshot): Promise<void> {
        const maxSnapshotSize = 100 * 1024 * 1024; // 100MB
        const totalSize = snapshot.files.reduce((sum, file) => sum + file.size, 0);
        
        if (totalSize > maxSnapshotSize) {
            throw new Error(`快照总大小(${this.formatSize(totalSize)})超过限制(${this.formatSize(maxSnapshotSize)})`);
        }
        
        const workspaceRoot = vscode.workspace.workspaceFolders?.[0].uri.fsPath;
        if (!workspaceRoot) {
            throw new Error('未打开工作区');
        }

        try {
            // 清理旧快照
            await this.cleanupOldSnapshots();
            
            // 保存新快照
            await FileUtils.saveSnapshotToFile(snapshot, workspaceRoot);
            
            // 添加状态栏提示
            vscode.window.setStatusBarMessage(`快照 "${snapshot.name}" 已保存`, 3000);
        } catch (error) {
            console.error('Error saving snapshot:', error);
            throw new Error(`保存快照失败: ${error}`);
        }
    }

    async getAllSnapshots(): Promise<Snapshot[]> {
        const workspaceRoot = vscode.workspace.workspaceFolders?.[0].uri.fsPath;
        if (!workspaceRoot) {
            return [];
        }
        return FileUtils.getAllSnapshots(workspaceRoot);
    }

    async getSnapshotById(id: string): Promise<Snapshot | undefined> {
        const workspaceRoot = vscode.workspace.workspaceFolders?.[0].uri.fsPath;
        if (!workspaceRoot) {
            return undefined;
        }
        try {
            return await FileUtils.loadSnapshotFromFile(id, workspaceRoot);
        } catch {
            return undefined;
        }
    }

    async deleteSnapshot(id: string): Promise<void> {
        const workspaceRoot = vscode.workspace.workspaceFolders?.[0].uri.fsPath;
        if (!workspaceRoot) {
            return;
        }
        const snapshotDir = await FileUtils.ensureSnapshotDir(workspaceRoot);
        const files = await fs.promises.readdir(snapshotDir);
        const snapshotFile = files.find(f => f.includes(`snapshot_${id}.json`) || f.includes(`_snapshot_${id}.json`));
        if (snapshotFile) {
            const filePath = path.join(snapshotDir, snapshotFile);
            try {
                await fs.promises.unlink(filePath);
            } catch (error) {
                console.error('Error deleting snapshot:', error);
                throw new Error(`删除快照失败: ${error}`);
            }
        }
    }

    async cleanupOldSnapshots(): Promise<void> {
        const workspaceRoot = vscode.workspace.workspaceFolders?.[0].uri.fsPath;
        if (!workspaceRoot) {
            return;
        }

        const config = vscode.workspace.getConfiguration('codeSnapshot');
        const maxSnapshots = config.get<number>('maxSnapshots', 50);
        
        const snapshots = await this.getAllSnapshots();
        if (snapshots.length > maxSnapshots) {
            const sortedSnapshots = snapshots.sort((a, b) => b.timestamp - a.timestamp);
            const toDelete = sortedSnapshots.slice(maxSnapshots);
            
            // 删除多余的快照文件
            for (const snapshot of toDelete) {
                await this.deleteSnapshot(snapshot.id);
            }
        }
    }

    async searchSnapshots(query: string): Promise<Snapshot[]> {
        const snapshots = await this.getAllSnapshots();
        return snapshots.filter(s => 
            s.name.toLowerCase().includes(query.toLowerCase()) ||
            s.description?.toLowerCase().includes(query.toLowerCase()) ||
            s.tags?.some(tag => tag.toLowerCase().includes(query.toLowerCase()))
        );
    }

    formatSize(bytes: number): string {
        const units = ['B', 'KB', 'MB', 'GB'];
        let size = bytes;
        let unitIndex = 0;
        
        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }
        
        return `${size.toFixed(2)}${units[unitIndex]}`;
    }
} 