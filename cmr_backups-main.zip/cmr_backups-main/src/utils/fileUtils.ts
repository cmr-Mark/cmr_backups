import * as vscode from 'vscode';
import * as path from 'path';
import * as fs from 'fs';

export class FileUtils {
    static async ensureSnapshotDir(workspaceRoot: string): Promise<string> {
        const config = vscode.workspace.getConfiguration('codeSnapshot');
        const customBackupPath = config.get<string>('backupPath', '');
        
        if (customBackupPath) {
            try {
                await fs.promises.access(path.dirname(customBackupPath));
            } catch (error) {
                throw new Error(`自定义备份路径无效: ${error}`);
            }
        }
        
        const snapshotDir = customBackupPath 
            ? path.resolve(customBackupPath)
            : path.join(workspaceRoot, '.snapshots');

        if (!fs.existsSync(snapshotDir)) {
            await fs.promises.mkdir(snapshotDir, { recursive: true });
        }
        return snapshotDir;
    }

    static async saveSnapshotToFile(snapshot: any, workspaceRoot: string): Promise<void> {
        const snapshotDir = await this.ensureSnapshotDir(workspaceRoot);
        const datePrefix = new Date().toISOString().split('T')[0];
        const fileName = `${datePrefix}_snapshot_${snapshot.id}.json`;
        const filePath = path.join(snapshotDir, fileName);
        
        try {
            await fs.promises.writeFile(filePath, JSON.stringify(snapshot, null, 2), 'utf8');
            console.log(`Snapshot saved to: ${filePath}`);
        } catch (error) {
            console.error('Error saving snapshot:', error);
            throw new Error(`保存快照失败: ${error}`);
        }
    }

    static async loadSnapshotFromFile(id: string, workspaceRoot: string): Promise<any> {
        const snapshotDir = await this.ensureSnapshotDir(workspaceRoot);
        const files = await fs.promises.readdir(snapshotDir);
        const snapshotFile = files.find(f => f.includes(`snapshot_${id}.json`) || f.includes(`_snapshot_${id}.json`));
        if (!snapshotFile) {
            throw new Error('快照文件不存在');
        }
        const filePath = path.join(snapshotDir, snapshotFile);
        try {
            const content = await fs.promises.readFile(filePath, 'utf8');
            return JSON.parse(content);
        } catch (error) {
            console.error('Error reading snapshot:', error);
            throw new Error(`读取快照失败: ${error}`);
        }
    }

    static async getAllSnapshots(workspaceRoot: string): Promise<any[]> {
        const snapshotDir = await this.ensureSnapshotDir(workspaceRoot);
        if (!fs.existsSync(snapshotDir)) {
            return [];
        }
        
        try {
            const files = await fs.promises.readdir(snapshotDir);
            const snapshots = [];
            
            // 按日期排序文件
            const sortedFiles = files
                .filter(f => f.endsWith('.json'))
                .sort((a, b) => {
                    const dateA = a.split('_')[0];
                    const dateB = b.split('_')[0];
                    return dateB.localeCompare(dateA);
                });

            for (const file of sortedFiles) {
                try {
                    const filePath = path.join(snapshotDir, file);
                    const content = await fs.promises.readFile(filePath, 'utf8');
                    const snapshot = JSON.parse(content);
                    // 添加文件名信息
                    snapshot.fileName = file;
                    snapshots.push(snapshot);
                } catch (error) {
                    console.error(`Error reading snapshot file ${file}:`, error);
                }
            }
            
            return snapshots;
        } catch (error) {
            console.error('Error reading snapshots directory:', error);
            return [];
        }
    }
} 