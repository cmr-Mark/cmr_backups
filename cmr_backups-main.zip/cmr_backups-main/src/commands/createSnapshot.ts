import * as vscode from 'vscode';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { Snapshot, SnapshotFile } from '../models/snapshot';
import { SnapshotStorage } from '../storage/snapshotStorage';

// 定义文件类型组的接口
interface FileTypeGroup {
    label: string;
    types: string[];
    icon: string;
    description?: string;
}

// 定义选择类型的接口
interface TypeSelection {
    label: string;
    description: string;
    detail?: string;
    types: string[];
}

// 文件类型分类函数
function categorizeFileType(ext: string): string {
    ext = ext.toLowerCase();
    // 根据扩展名判断文件类型
    if (['.js', '.ts', '.py', '.java', '.cpp', '.c', '.cs', '.go', '.rs', '.php', '.rb'].includes(ext)) {
        return 'code';
    }
    if (['.json', '.yaml', '.yml', '.xml', '.toml', '.ini'].includes(ext)) {
        return 'config';
    }
    if (['.md', '.txt', '.doc', '.docx', '.pdf'].includes(ext)) {
        return 'document';
    }
    if (['.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico'].includes(ext)) {
        return 'image';
    }
    if (['.sql', '.db', '.sqlite'].includes(ext)) {
        return 'data';
    }
    return 'other';
}

export async function createSnapshot(context: vscode.ExtensionContext): Promise<void> {
    try {
        const workspaceRoot = vscode.workspace.workspaceFolders?.[0].uri.fsPath;
        if (!workspaceRoot) {
            throw new Error('No workspace folder open');
        }

        // 获取配置的排除模式 - 移到前面来
        const config = vscode.workspace.getConfiguration('codeSnapshot');
        const defaultExcludePatterns = config.get<string[]>('excludePatterns', []);
        const customExcludePatterns = config.get<string[]>('customExcludePatterns', []);

        // 获取所有工作区文件和文件夹
        const allFiles = await vscode.workspace.findFiles('**/*');
        const uniqueDirs = new Set<string>();
        allFiles.forEach(file => {
            let dir = path.dirname(file.fsPath);
            while (dir !== workspaceRoot) {
                uniqueDirs.add(path.relative(workspaceRoot, dir));
                dir = path.dirname(dir);
            }
        });

        // 让用户选择要排除的文件和文件夹
        const items = [
            { label: '$(files) 备份所有文件', type: 'all', description: '备份工作区内的所有文件' },
            { label: '$(symbol-file) 按文件类型备份', type: 'byType', description: '选择要备份的文件类型' },
            { label: '$(file) 选择要排除的文件', type: 'file', description: '选择要排除的具体文件' },
            { label: '$(folder) 选择要排除的文件夹', type: 'folder', description: '选择要排除的整个文件夹' }
        ];

        const selection = await vscode.window.showQuickPick(items, {
            placeHolder: '请选择备份方式（必选）',
            ignoreFocusOut: true
        });

        if (!selection) {
            // 用户取消了选择
            return;
        }

        let excludePatterns: string[] = [];
        if (selection.type === 'all') {
            // 使用最小的排除规则
            excludePatterns = [
                '**/node_modules/**',
                '**/.git/**',
                '**/.DS_Store',
                '**/.snapshots/**'
            ];
        } else if (selection.type === 'byType') {
            // 获取工作区中所有的文件类型
            const fileTypes = new Map<string, Set<string>>();
            allFiles.forEach(file => {
                const ext = path.extname(file.fsPath).toLowerCase();
                if (ext) {
                    const category = categorizeFileType(ext);
                    if (!fileTypes.has(category)) {
                        fileTypes.set(category, new Set());
                    }
                    fileTypes.get(category)?.add(ext);
                }
            });

            // 构建类型组
            const typeGroups: FileTypeGroup[] = [];
            
            // 代码文件
            if (fileTypes.has('code')) {
                typeGroups.push({
                    label: '代码文件',
                    icon: '$(code)',
                    types: Array.from(fileTypes.get('code') || []),
                    description: '编程语言源代码文件'
                });
            }

            // 配置文件
            if (fileTypes.has('config')) {
                typeGroups.push({
                    label: '配置文件',
                    icon: '$(json)',
                    types: Array.from(fileTypes.get('config') || []),
                    description: '项目配置和设置文件'
                });
            }

            // 文档文件
            if (fileTypes.has('document')) {
                typeGroups.push({
                    label: '文档文件',
                    icon: '$(markdown)',
                    types: Array.from(fileTypes.get('document') || []),
                    description: '文档和文本文件'
                });
            }

            // 图片文件
            if (fileTypes.has('image')) {
                typeGroups.push({
                    label: '图片文件',
                    icon: '$(image)',
                    types: Array.from(fileTypes.get('image') || []),
                    description: '图片和图形文件'
                });
            }

            // 数据文件
            if (fileTypes.has('data')) {
                typeGroups.push({
                    label: '数据文件',
                    icon: '$(database)',
                    types: Array.from(fileTypes.get('data') || []),
                    description: '数据库和数据文件'
                });
            }

            // 其他文件
            if (fileTypes.has('other')) {
                typeGroups.push({
                    label: '其他文件',
                    icon: '$(file-binary)',
                    types: Array.from(fileTypes.get('other') || []),
                    description: '未分类的其他类型文件'
                });
            }

            if (typeGroups.length === 0) {
                throw new Error('工作区中没有可备份的文件');
            }

            const selectedTypes = await vscode.window.showQuickPick(
                typeGroups.map(group => ({
                    label: `${group.icon} ${group.label}`,
                    description: `${group.types.join(', ')} (${group.types.length}个文件类型)`,
                    detail: group.description,
                    types: group.types
                })), {
                    canPickMany: true,
                    placeHolder: '选择要备份的文件类型（可多选）',
                    ignoreFocusOut: true
                }
            );

            if (!selectedTypes || selectedTypes.length === 0) {
                throw new Error('请至少选择一个文件类型');
            }

            // 修改排除模式构建
            const includedTypes = selectedTypes.flatMap(g => g.types);
            excludePatterns = [
                ...defaultExcludePatterns,
                ...Array.from(fileTypes.values())  // 修改这里
                    .flatMap(typeSet => Array.from(typeSet))
                    .filter(ext => !includedTypes.includes(ext))
                    .map(ext => `**/*${ext}`)
            ];

            // 添加日志
            console.log('Selected file types:', includedTypes);
            console.log('Exclude patterns:', excludePatterns);
        } else if (selection.type === 'folder') {
            const folders = Array.from(uniqueDirs).map(dir => ({
                label: dir || '根目录',
                picked: false
            }));
            const selectedFolders = await vscode.window.showQuickPick(folders, {
                canPickMany: true,
                placeHolder: '选择要排除的文件夹（可多选）',
                ignoreFocusOut: true
            });
            if (selectedFolders) {
                excludePatterns = selectedFolders.map(f => 
                    f.label === '根目录' ? '**/*' : `**/${f.label}/**`
                );
            }
        } else if (selection.type === 'file') {
            const files = allFiles.map(f => ({
                label: path.relative(workspaceRoot, f.fsPath),
                picked: false
            }));
            const selectedFiles = await vscode.window.showQuickPick(files, {
                canPickMany: true,
                placeHolder: '选择要排除的文件（可多选）',
                ignoreFocusOut: true
            });
            if (selectedFiles) {
                excludePatterns = selectedFiles.map(f => f.label);
            }
        }

        // 获取用户输入的快照名称
        const inputName = await vscode.window.showInputBox({
            prompt: '请输入快照名称（必填）',
            placeHolder: '例如：重要功能完成',
            ignoreFocusOut: true,
            validateInput: text => {
                return text.trim() ? null : '快照名称不能为空';
            }
        });

        if (!inputName) {
            // 用户取消了输入
            return;
        }

        const snapshotName = inputName.trim();

        // 合并所有排除模式
        const allExcludePatterns = [
            '**/.snapshots/**',
            ...defaultExcludePatterns,
            ...customExcludePatterns,
            ...excludePatterns
        ];
        
        // 构建 glob 模式
        const excludeGlob = `{${allExcludePatterns.join(',')}}`;
        
        // 添加文件大小限制
        const maxFileSize = config.get<number>('maxFileSize', 1024 * 1024); // 默认1MB
        
        // 获取所有工作区文件
        const files = await vscode.workspace.findFiles('**/*', excludeGlob);
        
        const snapshotFiles: SnapshotFile[] = [];
        const batchSize = 100;
        const batches = Math.ceil(files.length / batchSize);

        for (let i = 0; i < batches; i++) {
            const batchFiles = files.slice(i * batchSize, (i + 1) * batchSize);
            const batchPromises = batchFiles.map(async file => {
                try {
                    const stat = await vscode.workspace.fs.stat(file);
                    if (stat.size > maxFileSize) {
                        return null;
                    }
                    
                    const content = await vscode.workspace.fs.readFile(file);
                    const relativePath = path.relative(workspaceRoot, file.fsPath).replace(/\\/g, '/');
                    
                    return {
                        path: relativePath,
                        content: Buffer.from(content).toString('base64'),
                        lastModified: Date.now(),
                        size: stat.size,
                        type: path.extname(file.path),
                        readonly: false,
                        hash: await calculateFileHash(content)
                    } as SnapshotFile;  // 使用类型断言
                } catch (error) {
                    console.error(`处理文件失败: ${file.fsPath}`, error);
                    return null;
                }
            });
            
            const batchResults = await Promise.all(batchPromises);
            snapshotFiles.push(...batchResults.filter((result): result is SnapshotFile => 
                result !== null && typeof result.hash === 'string'
            ));
        }

        // 添加进度提示
        vscode.window.withProgress({
            location: vscode.ProgressLocation.Notification,
            title: "正在创建快照...",
            cancellable: false
        }, async (progress) => {
            progress.report({ increment: 0 });
            // ... 创建快照的代码 ...
            progress.report({ increment: 100 });
        });

        // 创建快照
        const snapshot: Snapshot = {
            id: uuidv4(),
            timestamp: Date.now(),
            name: snapshotName,
            files: snapshotFiles,
            workspaceRoot,
            fileCount: snapshotFiles.length,
            totalSize: snapshotFiles.reduce((sum, file) => sum + file.size, 0),
            lastModified: Date.now(),
            version: 1
        };

        // 保存快照
        const storage = new SnapshotStorage(context);
        await storage.saveSnapshot(snapshot);

        // 使用正确的刷新命令
        await vscode.commands.executeCommand('codeSnapshot.refreshTree');

        vscode.window.showInformationMessage(`快照"${snapshotName}"创建成功！`);
    } catch (error: any) {
        vscode.window.showErrorMessage(`快照创建失败: ${error?.message || '未知错误'}`);
    }
}

// 生成默认快照名称
function generateDefaultName(): string {
    const now = new Date();
    const activeEditor = vscode.window.activeTextEditor;
    let prefix = '快照';
    
    // 如果有活动编辑器，使用文件名作为前缀
    if (activeEditor) {
        const fileName = path.basename(activeEditor.document.fileName);
        prefix = fileName.split('.')[0];
    }
    
    // 格式化时间
    const timeStr = now.toLocaleTimeString('zh-CN', {
        hour: '2-digit',
        minute: '2-digit'
    });
    const dateStr = now.toLocaleDateString('zh-CN', {
        month: '2-digit',
        day: '2-digit'
    });
    
    return `${prefix}_${dateStr}_${timeStr}`;
}

// 添加计算文件哈希的辅助函数
async function calculateFileHash(content: Uint8Array): Promise<string> {
    const crypto = require('crypto');
    const hash = crypto.createHash('sha256');
    hash.update(content);
    return hash.digest('hex');
} 